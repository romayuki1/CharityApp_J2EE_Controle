package com.charityapp.controle.services;

import com.charityapp.controle.Projection.CampagneResume;
import com.charityapp.controle.repository.CampagneJPA;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;

@Service
public class ServiceCampagne{
    private final CampagneJPA campagneRepository;

    public ServiceCampagne(CampagneJPA campagneRepository) {
        this.campagneRepository = campagneRepository;
    }

    public List<CampagneResume> getActiveCampagnes() {
        return campagneRepository.findActiveCampagnes(LocalDate.now());
    }
}