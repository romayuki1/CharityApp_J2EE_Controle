package com.charityapp.controle.service;

import com.charityapp.controle.Projection.CampagneResume;
import com.charityapp.controle.repository.CampagneJPA;
import com.charityapp.controle.services.ServiceCampagne;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import java.time.LocalDate;
import java.util.List;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class CampagneServiceTest {
    @Mock
    private CampagneJPA campagneRepository;

    @InjectMocks
    private ServiceCampagne campagneService;

    @Test
    public void testGetActiveCampagnes() {
        when(campagneRepository.findActiveCampagnes(any(LocalDate.class)))
                .thenReturn(List.of());

        List<CampagneResume> result = campagneService.getActiveCampagnes();
        assertNotNull(result);
        assertEquals(0, result.size());
    }
}