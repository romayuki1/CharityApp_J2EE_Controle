package com.charityapp.controle.Controllers;

import com.charityapp.controle.DTO.DonDTO;
import com.charityapp.controle.models.Donation;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.charityapp.controle.services.ServiceDon;

@RestController
@RequestMapping("/api/campagnes")
public class DonController {
    private final ServiceDon donService;

    public DonController(ServiceDon donService) {
        this.donService = donService;
    }

    @PostMapping("/{id}/dons")
    public ResponseEntity<DonDTO> saveDonation(
            @PathVariable Long id,
            @Valid @RequestBody DonDTO donDTO) {
        Donation donation = donService.saveDonation(donDTO);
        return ResponseEntity.ok(donService.convertToDTO(donation));
    }
}