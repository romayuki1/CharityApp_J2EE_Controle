package com.charityapp.controle.repository;

import com.charityapp.controle.models.Donation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DonationJPA extends JpaRepository<Donation, Long> {

}