package com.charityapp.controle.services;

import com.charityapp.controle.DTO.DonDTO;
import com.charityapp.controle.models.Campagne;
import com.charityapp.controle.models.Donation;
import com.charityapp.controle.repository.CampagneJPA;
import com.charityapp.controle.repository.DonationJPA;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;

@Service
public class ServiceDon {
    private final DonationJPA donationRepository;
    private final CampagneJPA campagneRepository;

    public ServiceDon(DonationJPA donationRepository, CampagneJPA campagneRepository) {
        this.donationRepository = donationRepository;
        this.campagneRepository = campagneRepository;
    }

    @Transactional
    public Donation saveDonation(DonDTO donDTO) {
        Campagne campagne = campagneRepository.findByNom(donDTO.getNomCampagne())
                .orElseThrow(() -> new RuntimeException("Campaign not found"));

        Donation donation = new Donation();
        donation.setCampagne(campagne);
        donation.setNomDonateur(donDTO.getNomDonateur());
        donation.setMontant(donDTO.getMontant());
        donation.setDate(donDTO.getDate() != null ? donDTO.getDate() : LocalDate.now());

        return donationRepository.save(donation);
    }

    public DonDTO convertToDTO(Donation donation) {
        DonDTO dto = new DonDTO();
        dto.setId(donation.getId());
        dto.setNomCampagne(donation.getCampagne().getNom());
        dto.setNomDonateur(donation.getNomDonateur());
        dto.setMontant(donation.getMontant());
        dto.setDate(donation.getDate());
        return dto;
    }
}
