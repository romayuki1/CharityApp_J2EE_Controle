package com.charityapp.controle.Projection;

import java.math.BigDecimal;

public interface CampagneResume {
    Long getId();
    String getNom();
    BigDecimal getObjectifMontant();
}