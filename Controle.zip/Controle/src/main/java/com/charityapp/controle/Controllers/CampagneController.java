package com.charityapp.controle.Controllers;

import com.charityapp.controle.Projection.CampagneResume;
import com.charityapp.controle.services.ServiceCampagne;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/campagnes")
public class CampagneController {
    private final ServiceCampagne campagneService;

    public CampagneController(ServiceCampagne campagneService) {
        this.campagneService = campagneService;
    }

    @GetMapping("/actives")
    public List<CampagneResume> getActiveCampagnes() {
        return campagneService.getActiveCampagnes();
    }
}
