package com.charityapp.controle.repository;

import com.charityapp.controle.Projection.CampagneResume;
import com.charityapp.controle.models.Campagne;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.Query;

@Repository
public interface CampagneJPA extends JpaRepository<Campagne, Long> {

    @Query("SELECT c.id as id, c.nom as nom, c.objectifMontant as objectifMontant " +
            "FROM Campagne c WHERE c.dateDebut <= :today AND c.dateFin >= :today")
    List<CampagneResume> findActiveCampagnes(LocalDate today);

    // ✅ Méthode pour chercher une campagne par nom (utilisée dans ServiceDon)
    Optional<Campagne> findByNom(String nom);
}
